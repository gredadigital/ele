<?php
/* Template name: Under Construction*/

get_header();
?>
<main class="bg-primario h-screen-safe flex flex-col justify-center items-center absolute w-full top-0 z-40">
    <div class="w-[300px] h-[300px] bg-[url(../images/logo_blanco.svg)] bg-no-repeat bg-center bg-contain">

    </div>
    <h2 class="text-white letter tracking-widest">EN CONSTRUCCIÓN</h2>

</main>


<?php
get_footer();
?>
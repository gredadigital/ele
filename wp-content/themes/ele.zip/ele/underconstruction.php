<?php
/* Template name: Under Construction*/

get_header();
?>
<div class="bg-primario h-screen-safe flex flex-col justify-center items-center absolute w-full top-0 z-40">
    <div class="w-[300px] h-[300px] bg-[url(../images/logo_blanco.svg)] bg-no-repeat bg-center bg-contain">
    </div>
</div>


<?php
get_footer();
?>